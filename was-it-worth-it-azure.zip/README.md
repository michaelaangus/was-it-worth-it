# Was It Worth It? — Azure deployment bundle

This directory is a fully self-contained deployment of the app. Azure App
Service (Linux, Node 20) will run `npm start` which executes `index.mjs`.

## Required environment variables

| Name                    | Description                                  |
| ----------------------- | -------------------------------------------- |
| `SUPABASE_DATABASE_URL` | Supabase Postgres pooler connection string. |
| `PORT`                  | Set automatically by Azure App Service.     |

See `.env.example` for format.

## Deploy

See `AZURE_DEPLOY.md` at the repo root for click-by-click instructions.
